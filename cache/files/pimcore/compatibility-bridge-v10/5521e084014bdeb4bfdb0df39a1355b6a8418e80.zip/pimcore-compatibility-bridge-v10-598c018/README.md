# Compatibility Bridge

Pimcore Compatibility Bridge provides class aliases for the classes which were moved/updated and are necessary for backwards compatibility